from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .models import Feedback
from .models import Text


@csrf_exempt
def create_text(request, TextInput):
    if request.method == 'POST':
        text = Text.objects.create(
            original_text=TextInput['original_text'],
            corrected_text=TextInput['corrected_text'],
            labeled_text=TextInput['labeled_text']
        )
        response_data = {
            'id': text.id,
            'original_text': text.original_text,
            'corrected_text': text.corrected_text,
            'labeled_text': text.labeled_text
        }
        return JsonResponse(response_data, status=201), text.id
    else:
        return JsonResponse({'error': 'Only POST requests are allowed.'}, status=400)


@csrf_exempt
def get_text(request, text_id):
    try:
        text_id = Text.objects.get(pk=text_id)
        response_data = {
            'original_text': text_id.original_text,
            'corrected_text': text_id.corrected_text,
            'feedback': text_id.feedback,
            'created_at': text_id.created_at,
            'labeled_text': text_id.labeled_text
        }
        return JsonResponse(response_data), text_id.original_text, text_id.corrected_text, text_id, text_id.labeled_text
    except Text.DoesNotExist:
        return JsonResponse({'error': 'Text not found.'}, status=404)


@csrf_exempt
def update_text(request, text_id, feedback):
    if request.method == 'PUT':
        try:
            text = Text.objects.get(pk=text_id)
            text.original_text = text.original_text
            text.corrected_text = text.corrected_text
            text.feedback = feedback
            text.labeled_text = text.labeled_text
            text.save()
            response_data = {
                'id': text.id,
                'original_text': text.original_text,
                'corrected_text': text.corrected_text,
                'feedback': text.feedback,
                'created_at': text.created_at,
                'labeled_text': text.labeled_text
            }
            return JsonResponse(response_data)
        except Text.DoesNotExist:
            return JsonResponse({'error': 'Text not found.'}, status=404)
    else:
        return JsonResponse({'error': 'Only PUT requests are allowed.'}, status=400)


@csrf_exempt
def delete_text(request, text_id):
    if request.method == 'DELETE':
        try:
            text = Text.objects.get(pk=text_id)
            text.delete()
            return JsonResponse({'success': True})
        except Text.DoesNotExist:
            return JsonResponse({'error': 'Text not found.'}, status=404)
    else:
        return JsonResponse({'error': 'Only DELETE requests are allowed.'}, status=400)


@csrf_exempt
def create_feedback(request, FeedbackInput):
    if request.method == 'POST':
        feedback = Feedback.objects.create(
            feedback_data=FeedbackInput['feedback_data'],
        )
        response_data = {
            'id': feedback.id,
            'feedback_data': feedback.feedback_data,
        }
        return JsonResponse(response_data, status=201), feedback.id
    else:
        return JsonResponse({'error': 'Only POST requests are allowed.'}, status=400)
