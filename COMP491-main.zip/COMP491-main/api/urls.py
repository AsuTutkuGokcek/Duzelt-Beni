from django.urls import path

from api.views import FeedbackListCreate
from api.views import TextListCreate

urlpatterns = [
    path('text/', TextListCreate.as_view()),
    path('feedback/', FeedbackListCreate.as_view()),
]
