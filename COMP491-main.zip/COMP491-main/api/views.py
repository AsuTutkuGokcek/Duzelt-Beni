from rest_framework import generics

from api.models import Feedback
from api.models import Text
from duzeltbeni.serializers import FeedbackSerializer
from duzeltbeni.serializers import TextSerializer


class TextListCreate(generics.ListCreateAPIView):
    queryset = Text.objects.all()
    serializer_class = TextSerializer


class FeedbackListCreate(generics.ListCreateAPIView):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer
