from django.urls import path

from . import views

# http://127.0.0.1:8000/


urlpatterns = [
    path('', views.sendData, name='sendData')
    # path('', views.sendtext, name='sendtext'),
    # path('sendapi/', views.sendapi, name='sendapi'),
    # path('feedback/', views.sendfeedback, name='sendfeedback'),
]
