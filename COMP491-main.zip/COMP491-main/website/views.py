from django.http import JsonResponse
from django.shortcuts import render
import api.api
from model.text_corrector_cache import get_text_corrector


def sendData(request):
    if request.method == 'POST':
        input_string = ""
        str_out = ""
        text_id = 0
        feedback = ""
        gfeedback = ""

        ## print(request.POST.get('dataType'))
        if request.POST.get('dataType') == 'sendtext':
            input_string = request.POST.get('input')
            text_corrector = get_text_corrector()
            final_input_string, final_output_string, str_out = text_corrector.process_text(input_string)
            text = final_output_string
            Text = {'original_text': input_string, 'corrected_text': text, 'labeled_text': str_out}
            created_text_json_data, text_id = api.api.create_text(request, Text)
            return render(request, 'home.html', {'input': input_string, 'output': str_out, "text_id": text_id})
        elif request.POST.get('dataType') == 'sendapi':
            feedback = request.POST.get('feedback')
            text_id = request.POST.get('text_id')
            request.method = 'PUT'
            api.api.update_text(request, text_id, feedback)
            json, input_string, final_output_string, text_id, str_out = api.api.get_text(request, text_id)
            return render(request, 'home.html',
                          {'input': input_string, 'output': str_out, "text_id": text_id, 'feedback': feedback})
        elif request.POST.get('dataType') == 'sendfeedback':
            gfeedback = request.POST.get('gfeedback')
            Feedback = {'feedback_data': gfeedback}
            api.api.create_feedback(request, Feedback)
            return render(request, 'home.html',
                          {'input': input_string, 'output': str_out, "text_id": text_id,
                           'gfeedback': Feedback['feedback_data']})
        else:
            render(request, 'home.html')
    else:
        return render(request, 'home.html')


""""
def sendtext(request):
    if request.method == 'POST':
        input_string = request.POST.get('input')
        # print("input_string:", input_string)
        text_corrector = get_text_corrector()
        final_input_string, final_output_string, str_out = text_corrector.process_text(input_string)
        # print("final_input_string:", final_input_string)
        # print("final_output_string:", final_output_string)
        # print("str_out:", str_out)
        text = final_output_string
        Text = {'original_text': input_string, 'corrected_text': text}
        created_text_json_data, text_id = api.api.create_text(request, Text)
        # print("created_text_json_data:", created_text_json_data)
        # print("text_id:", text_id)

        return render(request, 'home.html', {'input': input_string, 'output': str_out, "text_id": text_id})
    else:
        return render(request, 'home.html')


def sendapi(request):
    if request.method == 'POST':
        feedback = request.POST.get('feedback', '')
        # print("feedback:", feedback)
        text_id = request.POST.get('text_id', '')
        # print("text_id:", text_id)
        request.method = 'PUT'
        updated_text = api.api.update_text(request, text_id, feedback)
        json, input_string, str_out, text_id = api.api.get_text(request, text_id)
        # print("json: ", json)
        # print("input_string: ", input_string)
        # print("str_out: ", str_out)
        # print("feedback: ", feedback)
        return render(request, 'home.html',
                      {'input': input_string, 'output': str_out, "text_id": text_id, 'feedback': feedback})
    else:
        return JsonResponse(request, 'home.html', {'status': 'failed'})


def sendfeedback(request):
    if request.method == 'POST':
        feedback = request.POST.get('gfeedback', '')
        Feedback = {'feedback_data': feedback}
        create_feedback = api.api.create_feedback(request, Feedback)
        # print("create_feedback")
        # print(create_feedback[0])
        Feedback = {'feedback_data': feedback}
        return render(request, 'home.html', {'gfeedback': Feedback['feedback_data']})
    else:
        return JsonResponse(request, 'home.html', {'status': 'failed'})
"""""
